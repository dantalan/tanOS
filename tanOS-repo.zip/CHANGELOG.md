# CHANGELOG · tanOS (talandanOS)

## v1.1.0 — 2026-06-22
[MINOR] Real authentication — replaced fake doLogin() with genuine Supabase auth

- signInWithPassword (email/password)
- signInWithOAuth Google
- Session persistence via getSession + onAuthStateChange
- Working logout button
- Role selection screen post-login

## v1.0.0 — 2026-06-21
[MAJOR] Initial tanOS unified build

- Dashboard, Units, Tenants, Payments, Invoices, Maintenance
- Attorney portal (read-only, Marinus)
- Invoice generator + Debit Order mandate generator
- CSV/Excel tenant import
- 28th rent due date locked throughout
- All contracts from 01.06.2026

_bluebaatjie sovereign · ONE. ◆_
