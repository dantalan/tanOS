# tanOS · talandanOS

> Sovereign property management. Node ONE.

Property management OS for the Talandan Trust. 26 units, Dantalan House, Ferndale/Randburg.

## Stack
- Single-file HTML · Supabase backend
- Project: `eoemulgphlkrpvabdznh`
- Deploy: `talandanos-app.netlify.app`

## Roles
- Admin (Dantalan) — full access
- Attorney (Marinus) — read-only portal
- Landlord — property + tenant management
- Service Provider — maintenance only

## Rules
- All contracts from 01.06.2026
- Rent due 28th monthly — non-negotiable
- Debit orders reflect 28th as due date

## Covenant
> s'dla sonke, s'fa sonke

**bluebaatjie sovereign · ONE. ◆ · 86417**
